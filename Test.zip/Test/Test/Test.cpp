
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <iterator>
#define INPUT_VECTOR_MAP vector<int>&, map<int, int>&
#define CONST_INPUT_VECTOR_MAP const vector<int>&, const map<int, int>&

using namespace std;

void full_map_vec(INPUT_VECTOR_MAP);//get numbers in vector and map
void erase_rand_vec_map(INPUT_VECTOR_MAP);//erase rand elements in vector and map
void sync_vec_map(INPUT_VECTOR_MAP);//sync equal elements in map and vector
void show_vec_map(CONST_INPUT_VECTOR_MAP);//print map and vector

const int CONTAIN_SIZE = 20;

int get_second(pair<int, int> i) { return i.second; }

int main()
{
    srand((unsigned int)time(NULL));

    vector<int> vec_first(CONTAIN_SIZE);
    map<int, int> map_first;

    full_map_vec(vec_first, map_first);
    erase_rand_vec_map(vec_first, map_first);
    show_vec_map( vec_first, map_first);
    sync_vec_map(vec_first, map_first);
    show_vec_map(vec_first, map_first);
}

void full_map_vec(vector<int>& vec_input, map<int, int>& map_input)
{
    for (int i = 0; i < CONTAIN_SIZE; i++)
    {
        vec_input[i] = rand() % 10;
        map_input[i] = rand() % 10;
    }
}

void erase_rand_vec_map(vector<int>& vec_input, map<int, int>& map_input)
{

    int temp = rand() % 15;
    vec_input.erase(vec_input.begin(), vec_input.begin() + temp);

    do
    {
        map_input.erase(map_input.begin());
        temp--;
    } while (temp != 0);

}

void sync_vec_map(vector<int>& vec_input, map<int, int>& map_input)
{
    sort(vec_input.begin(), vec_input.end());//sort vector

    vector<int> mapTransform(map_input.size());//transf map to vector

    transform(map_input.begin(), map_input.end(), mapTransform.begin(), get_second);//input numers to mapTransform

    sort(mapTransform.begin(), mapTransform.end());

    vector<int> intersectionElements;

    set_intersection(vec_input.begin(), vec_input.end(), mapTransform.begin(), mapTransform.end(), back_inserter(intersectionElements));//input equal element in intersectionElements


    auto predVector =
        [&](int value) -> bool {
        for (auto& i : intersectionElements) { if (value == i) { return false; } }
        return true;
    };

    vec_input.erase(
        remove_if(vec_input.begin(), vec_input.end(), predVector),
        vec_input.end());//remove elements

    auto predMap =
        [&](map<int, int>::value_type valueType) -> bool {
        for (auto& i : intersectionElements) { if (i == valueType.second) { return false; } }
        return true;
    };

    auto it = map_input.begin();
    while ((it = find_if(it, map_input.end(), predMap)) != map_input.end()) {
        map_input.erase(it++);
    }

}

void show_vec_map(vector<int>const& vec_input, map<int, int>const& map_input)
{
    cout << "Map: " << endl;

    for (auto i : map_input)
    {
        cout << " " << i.second << endl;;
    }

    cout << "Vector: " << endl;

    for (auto const& i : vec_input)
    {
        cout << i << " " << endl;
    }

}